package com.example.healthguide_

class FoodItem {
}