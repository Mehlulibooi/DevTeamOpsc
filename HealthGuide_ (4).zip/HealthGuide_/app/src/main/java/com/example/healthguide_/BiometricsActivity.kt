package com.example.healthguide_

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class BiometricsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_biometrics)  // Ensure this layout exists

        // Reference the back button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }
    }
}
