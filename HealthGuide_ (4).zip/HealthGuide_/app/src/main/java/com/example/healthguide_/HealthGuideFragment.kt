package com.example.healthguide_

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

//Code Attribution
// The code was referenced from GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/
//The author name is GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/

class HealthGuideFragment : Fragment(R.layout.fragment_health_guide) {

    private lateinit var listView: ListView

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_health_guide, container, false)

        // Reference to the ListView in the layout
        listView = view.findViewById(R.id.healthGuideListView)

        // List of sections to display
        val sections = arrayOf("Recipes Section", "Workout Section", "Food Section")

        // Adapter to bind the list of sections to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, sections)
        listView.adapter = adapter

        // Set a click listener for each item in the list
        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), RecipeSectionActivity::class.java))
                1 -> startActivity(Intent(requireContext(), WorkoutSectionActivity::class.java))
                2 -> startActivity(Intent(requireContext(), FoodSectionActivity::class.java))
            }
        }

        // Reference the Notification Bell
        val notificationBell: ImageButton = view.findViewById(R.id.notificationBell)

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            // Show dialog when bell is clicked
            showNotificationDialog()
        }

        return view
    }

    // Function to show a message dialog
    private fun showNotificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage("Take care of your body—it's the only place you have to live. Learn something new today to improve your well-being.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
