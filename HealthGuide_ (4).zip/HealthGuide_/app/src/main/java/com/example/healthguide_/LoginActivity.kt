package com.example.healthguide_

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var logoImage: ImageView
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvSignIn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize UI components
        initializeUI()

        // Populate fields with saved username and password
        populateFields()

        // Set up click listeners for buttons and text views
        setUpEventHandlers()
    }

    private fun initializeUI() {
        logoImage = findViewById(R.id.logoImage)
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvSignIn = findViewById(R.id.tvSignIn)
    }

    private fun populateFields() {
        val sharedPreferences = getSharedPreferences("userProfile", Context.MODE_PRIVATE)
        val savedUsername = sharedPreferences.getString("username", "")
        val savedPassword = sharedPreferences.getString("password", "")

        etUsername.setText(savedUsername)
        etPassword.setText(savedPassword)
    }

    private fun setUpEventHandlers() {
        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            } else {
                // Save the username to SharedPreferences
                val sharedPreferences = getSharedPreferences("userProfile", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                editor.putString("username", username)
                editor.apply()

                // Navigate to the Health Profile page after login
                val intent = Intent(this, HealthProfileActivity::class.java)
                startActivity(intent)
            }
        }

        tvSignIn.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }
    }
}
