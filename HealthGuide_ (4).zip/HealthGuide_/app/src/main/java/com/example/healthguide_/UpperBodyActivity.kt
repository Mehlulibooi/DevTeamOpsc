package com.example.healthguide_ // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class UpperBodyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upper_body) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImage: ImageView = findViewById(R.id.imageBeginner)
        val intermediateImage: ImageView = findViewById(R.id.imageIntermediate)
        val advancedImage: ImageView = findViewById(R.id.imageAdvanced)

        beginnerImage.setOnClickListener {
            showDetailsDialog("Beginner Details", "Push-ups (3 sets of 10)\n" +
                    "Dumbbell Shoulder Press (3 sets of 8)\n" +
                    "Bicep Curls (3 sets of 10)\n")
        }

        intermediateImage.setOnClickListener {
            showDetailsDialog("Intermediate Details", "Incline Push-ups (4 sets of 15)\n" +
                    "Barbell Bench Press (4 sets of 10)\n" +
                    "Tricep Dips (3 sets of 12)\n")
        }

        advancedImage.setOnClickListener {
            showDetailsDialog("Advanced Details", "Diamond Push-ups (5 sets of 20)\n" +
                    "Pull-ups (4 sets of 10)\n" +
                    "Overhead Press (4 sets of 12)\n" +
                    "Heavy Dumbbell Curls (4 sets of 12)")
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
