package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

//Code Attribution
//This code was referenced from StakeOverFlow
//https://stackoverflow.com/questions/44255551/user-profile-layout-with-edit-and-save-option
//The author name is Nilesh
//https://stackoverflow.com/users/7666442/asknilesh
class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome) // Make sure this layout name matches the XML file name

        // Reference to the Click Here button
        val clickHereButton: Button = findViewById(R.id.clickHereButton)

        // Set click listener for navigation to RegistrationActivity
        clickHereButton.setOnClickListener {
            // Create an Intent to navigate from WelcomeActivity to RegistrationActivity
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }
    }
}
