package com.example.healthguide_

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import android.view.animation.AnimationUtils
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var tvDate: TextView
    private lateinit var tvWelcomeUser: TextView // TextView for welcome message
    private lateinit var caloriesTextView: TextView
    private lateinit var heightTextView: TextView
    private lateinit var weightTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var stepsCountTextView: TextView
    private lateinit var distanceCoveredTextView: TextView
    private lateinit var waterCountTextView: TextView // TextView to display water consumption
    private lateinit var buttonIncrease: Button // Increase button
    private lateinit var buttonDecrease: Button // Decrease button
    private lateinit var notificationBell: ImageButton // Notification bell button

    private var stepCount = 0
    private var distanceInMeters = 0.0
    private var waterCount = 0 // Variable to track water consumption
    private val stepDistance = 0.762 // Average stride length in meters
    private val handler = Handler()
    private var duration = 0 // Duration in seconds

    private val runnable = object : Runnable {
        override fun run() {
            if (duration % 5 == 0) {
                stepCount++
                distanceInMeters = stepCount * stepDistance
                updateUI()
            }
            duration++
            handler.postDelayed(this, 1000) // Update every second
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize TextViews
        tvDate = view.findViewById(R.id.tvDate)
        tvWelcomeUser = view.findViewById(R.id.tvWelcomeUser) // Initialize welcome user TextView
        caloriesTextView = view.findViewById(R.id.caloriesTextView)
        heightTextView = view.findViewById(R.id.heightTextView)
        weightTextView = view.findViewById(R.id.weightTextView)
        ageTextView = view.findViewById(R.id.ageTextView)
        stepsCountTextView = view.findViewById(R.id.steps_count)
        distanceCoveredTextView = view.findViewById(R.id.distance_covered)
        waterCountTextView = view.findViewById(R.id.water_count) // Initialize water count TextView
        buttonIncrease = view.findViewById(R.id.button_increase) // Initialize increase button
        buttonDecrease = view.findViewById(R.id.button_decrease) // Initialize decrease button
        notificationBell = view.findViewById(R.id.notificationBell) // Initialize notification bell

        // Set the current date
        setCurrentDate()

        // Set up button click listeners
        buttonIncrease.setOnClickListener {
            waterCount++ // Increment water count
            updateWaterCountDisplay() // Update the display
        }

        buttonDecrease.setOnClickListener {
            if (waterCount > 0) {
                waterCount-- // Decrement water count, ensuring it doesn't go below zero
                updateWaterCountDisplay() // Update the display
            }
        }

        // Retrieve user data from SharedPreferences
        val sharedPreferences: SharedPreferences =
            requireActivity().getSharedPreferences("userProfile", Context.MODE_PRIVATE)
        val username =
            sharedPreferences.getString("username", "User") ?: "User" // Retrieve username
        val age = sharedPreferences.getString("age", "0") ?: "0"
        val height = sharedPreferences.getString("height", "0") ?: "0"
        val weight = sharedPreferences.getString("weight", "0") ?: "0"

        // Update the UI
        tvWelcomeUser.text = "Welcome $username" // Display welcome message
        ageTextView.text = "Age: $age Years"
        heightTextView.text = "Height: $height cm"
        weightTextView.text = "Weight: $weight kg"

        // Perform calorie calculation
        val calories = calculateCalories(age.toInt(), height.toInt(), weight.toInt())
        caloriesTextView.text = "Calories: $calories kcal"

        // Set touch listener to simulate hover effect for notification bell
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            // Show dialog when bell is clicked
            showNotificationDialog()
        }

        // Start the timer
        handler.post(runnable)
    }

    private fun setCurrentDate() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        tvDate.text = currentDate
    }

    private fun updateUI() {
        stepsCountTextView.text = "$stepCount steps"
        distanceCoveredTextView.text = String.format("%.2f meters", distanceInMeters)
    }

    private fun updateWaterCountDisplay() {
        waterCountTextView.text =
            "$waterCount glasses of water consumed" // Update water consumption display
    }

    // Function to show a message dialog for notifications
    private fun showNotificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage("Take care of your body—it's the only place you have to live. Learn something new today to improve your well-being.")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // Basic calorie calculation
    private fun calculateCalories(age: Int, height: Int, weight: Int): Int {
        return (10 * weight + 6.25 * height - 5 * age + 5).toInt()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(runnable) // Stop the timer when the fragment is paused
    }

    override fun onResume() {
        super.onResume()
        handler.post(runnable) // Restart the timer when the fragment resumes
    }
}
