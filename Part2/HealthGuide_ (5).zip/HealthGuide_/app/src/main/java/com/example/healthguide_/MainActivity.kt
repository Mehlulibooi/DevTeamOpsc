package com.example.healthguide_ // This should be the correct package for MainActivity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.healthguide.network.ApiClient // Use lowercase 'network'
import com.example.healthguide.network.ApiService // Use lowercase 'network'
import com.example.healthguide_.models.DietEntry // Import your models

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    // Fragments
    private val homeFragment = HomeFragment()
    private val dietTrackerFragment = DietTrackerFragment()
    private val healthGuideFragment = HealthGuideFragment()
    private val settingsFragment = SettingsFragment()

    // API Service instance
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize API service
        apiService = ApiClient.createService(ApiService::class.java)

        // Example API call
        makeExampleApiCall()

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        // Set up navigation item selection
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            val selectedFragment: Fragment = when (item.itemId) {
                R.id.navigation_home -> homeFragment
                R.id.navigation_diet_tracker -> dietTrackerFragment
                R.id.navigation_health_guide -> healthGuideFragment
                R.id.navigation_settings -> settingsFragment
                else -> homeFragment
            }

            // Replace the fragment
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, selectedFragment)
                .commit()

            true
        }

        // Set the default fragment when the activity is created for the first time
        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.navigation_home
        }
    }

    // Example method to demonstrate an API call
    private fun makeExampleApiCall() {
        val call = apiService.getDietEntries("someUserId") // Replace with actual userId

        call.enqueue(object : Callback<List<DietEntry>> {
            override fun onResponse(call: Call<List<DietEntry>>, response: Response<List<DietEntry>>) {
                if (response.isSuccessful) {
                    // Handle successful response
                    val data = response.body()
                    Toast.makeText(this@MainActivity, "API Success: ${data?.size} items retrieved", Toast.LENGTH_SHORT).show()
                } else {
                    // Handle response error
                    Toast.makeText(this@MainActivity, "API Error: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<DietEntry>>, t: Throwable) {
                // Handle network failure
                Toast.makeText(this@MainActivity, "API Failure: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
