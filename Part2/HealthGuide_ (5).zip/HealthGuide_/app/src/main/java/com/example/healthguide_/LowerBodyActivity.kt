package com.example.healthguide_ // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class LowerBodyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lower_body) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImageLowerBody: ImageView = findViewById(R.id.imageBeginnerLowerBody)
        val intermediateImageLowerBody: ImageView = findViewById(R.id.imageIntermediateLowerBody)
        val advancedImageLowerBody: ImageView = findViewById(R.id.imageAdvancedLowerBody)

        beginnerImageLowerBody.setOnClickListener {
            showDetailsDialog("Beginner Lower Body Details", "Bodyweight Squats (3 sets of 12)\n" +
                    "Glute Bridges (3 sets of 10)\n" +
                    "Lunges (3 sets of 8 per leg)\n")
        }

        intermediateImageLowerBody.setOnClickListener {
            showDetailsDialog("Intermediate Lower Body Details", "Goblet Squats (4 sets of 15)\n" +
                    "Bulgarian Split Squats (3 sets of 10 per leg)\n" +
                    "Deadlifts (4 sets of 10)\n")
        }

        advancedImageLowerBody.setOnClickListener {
            showDetailsDialog("Advanced Lower Body Details", "Barbell Back Squats (5 sets of 12)\n" +
                    "Weighted Step-ups (4 sets of 12)\n" +
                    "Sumo Deadlifts (4 sets of 10)\n" +
                    "Jump Squats (4 sets of 15)\n")
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
