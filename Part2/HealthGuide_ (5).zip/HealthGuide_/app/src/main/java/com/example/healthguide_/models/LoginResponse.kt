package com.example.healthguide_.models

data class LoginResponse(
    val username: String,
    val password: String
)
