package com.example.healthguide_

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DietTrackerFragment : Fragment() {

    private var totalCaloriesAllowed = 2500 // Total allowed kcals
    private var currentCalories = 0 // To track the calories user adds

    // Calories for each meal
    private val breakfastCalories = 45
    private val lunchCalories = 45
    private val dinnerCalories = 95

    // UI components
    private lateinit var addBreakfastButton: ImageButton
    private lateinit var addLunchButton: ImageButton
    private lateinit var addDinnerButton: ImageButton
    private lateinit var remainingCaloriesTextView: TextView


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_diet_tracker, container, false)

        // Adjust window insets for system UI if necessary
        ViewCompat.setOnApplyWindowInsetsListener(view.findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize buttons and TextView
        addBreakfastButton = view.findViewById(R.id.addbuttonb)
        addLunchButton = view.findViewById(R.id.add_button_l)
        addDinnerButton = view.findViewById(R.id.add_button_d)
        remainingCaloriesTextView = view.findViewById(R.id.remainingCaloriesTextView)

        // Update the remaining calories at the start
        updateRemainingCalories()

        // Set up click listeners for each meal
        addBreakfastButton.setOnClickListener {
            if (currentCalories + breakfastCalories <= totalCaloriesAllowed) {
                currentCalories += breakfastCalories
                updateRemainingCalories()
            }
            checkIfCaloriesExceeded()
        }

        addLunchButton.setOnClickListener {
            if (currentCalories + lunchCalories <= totalCaloriesAllowed) {
                currentCalories += lunchCalories
                updateRemainingCalories()
            }
            checkIfCaloriesExceeded()
        }

        addDinnerButton.setOnClickListener {
            if (currentCalories + dinnerCalories <= totalCaloriesAllowed) {
                currentCalories += dinnerCalories
                updateRemainingCalories()
            }
            checkIfCaloriesExceeded()
        }

        return view
    }

    private fun updateRemainingCalories() {
        val remainingCalories = totalCaloriesAllowed - currentCalories
        remainingCaloriesTextView.text = remainingCalories.toString()
    }

    private fun checkIfCaloriesExceeded() {
        if (currentCalories >= totalCaloriesAllowed) {
            disableAllAddButtons()
        }
    }

    private fun disableAllAddButtons() {
        addBreakfastButton.isEnabled = false
        addLunchButton.isEnabled = false
        addDinnerButton.isEnabled = false
    }
}
