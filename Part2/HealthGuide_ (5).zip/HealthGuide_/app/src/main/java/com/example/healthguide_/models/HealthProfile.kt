package com.example.healthguide_.models

data class HealthProfile(
    val age: Int,
    val weight: Float,
    val height: Float,
    val sex: String
)
