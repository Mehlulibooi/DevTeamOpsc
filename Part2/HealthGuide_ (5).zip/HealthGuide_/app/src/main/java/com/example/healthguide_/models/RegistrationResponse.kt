package com.example.healthguide_.models

data class RegistrationResponse(
    val username: String,
    val email: String,
    val password: String
)
