package com.example.healthguide_.models

data class DietEntry(
    val userId: String,
    val foodName: String,
    val mealType: String,
    val calories: Int,
    val proteins: Float,
    val carbs: Float,
    val fat: Float
)
