package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

//Code Attribution
//This code was referenced from GrowthDot
//https://growthdot.com/designs-for-your-help-center/
//The author name is Natalie Zhontsa
//Natalia Zhontsa@growthdot.com
class HelpSupportActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_support)

        // Back button to navigate to the previous screen
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Contact Us button
        val contactUsButton: Button = findViewById(R.id.contact_us_button)
        contactUsButton.setOnClickListener {
            // Create an email intent
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "message/rfc822"  // MIME type for email
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("support@vital-sync.com"))
            intent.putExtra(Intent.EXTRA_SUBJECT, "Help Request")

            // Pre-fill the email body with text
            intent.putExtra(Intent.EXTRA_TEXT, "Describe your issue here.")

            // Use a chooser for sending email
            try {
                startActivity(Intent.createChooser(intent, "Send Email"))
            } catch (e: android.content.ActivityNotFoundException) {
                // Show a message if no email app is available
                Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
