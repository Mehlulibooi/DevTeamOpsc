package com.example.healthguide.network

import com.example.healthguide_.models.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @GET("dietentries/{userId}")
    fun getDietEntries(@Path("userId") userId: String): Call<List<DietEntry>>

    @POST("dietentries")
    fun addDietEntry(@Body dietEntry: DietEntry): Call<DietEntry>

    @POST("customizations")
    fun updateCustomization(@Body customization: Customization): Call<Customization>

    @GET("healthprofiles/{userId}")
    fun getHealthProfile(@Path("userId") userId: String): Call<HealthProfile>

    @POST("login")
    fun login(@Body loginRequest: LoginResponse): Call<LoginResponse>

    @POST("register")
    fun register(@Body registrationRequest: RegistrationResponse): Call<RegistrationResponse>
}
