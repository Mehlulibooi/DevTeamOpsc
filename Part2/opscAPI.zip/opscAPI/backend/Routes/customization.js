import express from 'express';
import authMiddleware from '../middleware/authMiddleware.js';
import Customization from '../models/Customization.js';

const router = express.Router();

// Add customisation settings
router.post("/", authMiddleware, async (req, res) => {
    const { language, height, weight, fitnessGoal, difficultyLevel } = req.body;

    if (!language || !height || !weight || !fitnessGoal || !difficultyLevel) {
        return res.status(400).json({ message: "Please provide all necessary fields" });
    }

    try {
        const newCustomisation = new Customisation({
            language,
            height,
            weight,
            fitnessGoal,
            difficultyLevel,
        });

        const savedCustomisation = await newCustomisation.save();
        res.status(201).json({ message: 'Customisation settings saved', savedCustomisation });
    } catch (err) {
        console.error('Error saving customisation settings', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

export default router;