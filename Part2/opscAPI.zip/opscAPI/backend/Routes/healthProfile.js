import express from 'express';
import User from '../models/User.js'; // Adjust the path if necessary
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// Register a new user
router.post("/register", async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: "Please provide all necessary fields" });
    }

    try {
        const newUser = new User({
            username,
            email,
            password,  // Ensure you hash the password before saving
        });

        const savedUser = await newUser.save();
        res.status(201).json({ message: 'User registered', savedUser });
    } catch (err) {
        console.error('Error registering user', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

export default router;