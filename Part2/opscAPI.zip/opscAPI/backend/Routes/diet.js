// diet.js
import express from 'express';

const router = express.Router();

// GET /api/diet
router.get('/', (req, res) => {
    res.json({ message: 'Diet route is working' });
});

export default router;
