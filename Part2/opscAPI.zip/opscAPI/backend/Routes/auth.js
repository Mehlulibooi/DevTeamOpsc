import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import bruteForce  from '../middleware/bruteForceProtectionMiddleware.js';
import loginAttemptLogger from '../middleware/loginAttemptLogmiddleware.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET;

router.get('/', (req, res) => {
    res.send('Welcome to the auth route backend') 
});

//Registration
router.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        //Check if the username or email already exists
        const existingUser = await User.findOne({ $or: [{username}, {email}]})
        if (existingUser) {
            return res.status(400).json({message: "Username or email already exists"})
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10)

        //create a new user
        const newUser = new User({ username, email, password: hashedPassword});
        await newUser.save();

        res.status(201).json({message: "User registered successfully"})
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err});
    }
});

//Login
router.post("/login" , bruteForce.prevent, loginAttemptLogger, async (req, res) => {
  try {
    const { username, password } = req.body;

    //Find the user by username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    //Create a JWT token
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "1h" });

    res.json({ token });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err });
  }
});

export default router;