import express from 'express';
import DietEntry from '../models/DietEntry.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// Add a new diet entry
router.post("/", authMiddleware, async (req, res) => {
    const { mealType, calories, protein, carbs, fat } = req.body;

    if (!mealType || !calories || !protein || !carbs || !fat) {
        return res.status(400).json({ message: "Please provide all necessary fields" });
    }

    const newDietEntry = new DietEntry({
        userId: req.user.id,  // Assuming authMiddleware adds user to req
        mealType,
        calories,
        protein,
        carbs,
        fat,
    });

    try {
        const savedEntry = await newDietEntry.save();
        res.status(201).json({ message: 'Diet entry added', savedEntry });
    } catch (err) {
        console.error('Error adding diet entry', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

// Get all diet entries for the authenticated user
router.get("/", authMiddleware, async (req, res) => {
    try {
        const dietEntries = await DietEntry.find({ userId: req.user.id });
        res.json(dietEntries);
    } catch (err) {
        console.error('Error fetching diet entries', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

// Update a diet entry
router.put("/:id", authMiddleware, async (req, res) => {
    const { mealType, calories, protein, carbs, fat } = req.body;
    const updateFields = {};

    if (mealType) updateFields.mealType = mealType;
    if (calories) updateFields.calories = calories;
    if (protein) updateFields.protein = protein;
    if (carbs) updateFields.carbs = carbs;
    if (fat) updateFields.fat = fat;

    try {
        const updatedEntry = await DietEntry.findByIdAndUpdate(req.params.id, updateFields, { new: true });
        if (!updatedEntry) {
            return res.status(404).json({ message: 'Diet entry not found' });
        }
        res.json({ message: 'Diet entry updated', updatedEntry });
    } catch (err) {
        console.error('Error updating diet entry', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

// Delete a diet entry
router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const entry = await DietEntry.findById(req.params.id);
        if (!entry) {
            return res.status(404).json({ message: 'Diet entry not found' });
        }

        await DietEntry.findByIdAndDelete(req.params.id);
        res.json({ message: 'Diet entry deleted' });
    } catch (err) {
        console.error('Error deleting diet entry', err);
        res.status(500).json({ message: 'Server error', error: err });
    }
});

export default router;
