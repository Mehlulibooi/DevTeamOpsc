// config.js
import './config.js';
import dotenv from 'dotenv';
dotenv.config(); // Ensure environment variables are loaded