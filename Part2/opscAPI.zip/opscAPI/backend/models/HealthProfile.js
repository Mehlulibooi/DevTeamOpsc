import mongoose from "mongoose";

const healthProfileSchema = new mongoose.Schema({
    age: {
        type: Number,
        required: true,
        min: 0, // Ensure the age is a positive number
    },
    weight: {
        type: Number,
        required: true,
        min: 0, // Ensure the weight is a positive number
    },
    height: {
        type: Number,
        required: true,
        min: 0, // Ensure the height is a positive number
    },
    sex: {
        type: String,
        required: true,
        enum: ['Male', 'Female', 'Other'], // Restricted to predefined values
    }
});

export default mongoose.model('HealthProfile', healthProfileSchema);