import mongoose from "mongoose";

const customisationSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId, // Reference to User
        required: true,
        ref: "User",
    },
    language: {
        type: String,
        required: true,
    },
    height: {
        type: Number,
        required: true,
    },
    weight: {
        type: Number,
        required: true,
    },
    fitnessGoal: {
        type: String,
        required: true,
    },
    difficultyLevel: {
        type: String,
        required: true,
    },
});

export default mongoose.model('Customisation', customisationSchema);