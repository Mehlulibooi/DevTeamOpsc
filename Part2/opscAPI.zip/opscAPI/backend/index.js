import './config.js'; // Load environment variables first
import express from 'express';
import cors from "cors";
import https from 'https';
import helmet from 'helmet';
import morgan from 'morgan';
import fs from 'fs';
import connectDB from './db/conn.js';
import authRoutes from './Routes/auth.js'; // User registration route
import loginRoutes from './Routes/login.js'; // Login route
import healthProfileRoutes from './Routes/healthProfile.js'; // Health profile routes
import customizationRoutes from './Routes/customization.js';
import dietRoutes from './Routes/diet.js';

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to database
connectDB();

// Middleware
app.use(express.json());
app.use(helmet());
app.use(morgan('combined'));
app.use(cors()); // Added CORS for cross-origin requests

// Routes
app.use('/api/auth', authRoutes); // Registration routes
app.use('/api/login', loginRoutes); // Login routes
app.use('/api/diet', dietRoutes); // Diet-related routes
app.use('/api/health-profile', healthProfileRoutes); // Health profile routes
app.use('/api/customization', customizationRoutes); // Customisation settings routes

// SSL certificate and key
const options = {
    key: fs.readFileSync('keys/privatekey.pem'),
    cert: fs.readFileSync('keys/certificate.pem')
};

// Start the server
https.createServer(options, app).listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});