package com.example.healthguide_

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageButton
import android.widget.ArrayAdapter
import android.widget.Spinner
// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class CustomisationOptionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customisation_options)

        // Ensure this ID matches the one in the layout file
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Set up the Spinner
        val fitnessGoalSpinner: Spinner = findViewById(R.id.fitnessGoalSpinner)

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            this,
            R.array.fitness_goals,  // This is the array defined in strings.xml
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

            // Apply the adapter to the spinner
            fitnessGoalSpinner.adapter = adapter
        }
    }
}
