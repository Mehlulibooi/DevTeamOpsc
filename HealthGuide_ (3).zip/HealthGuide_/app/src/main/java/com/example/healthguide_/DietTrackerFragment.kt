package com.example.healthguide_

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class DietTrackerFragment : Fragment() {

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_diet_tracker, container, false)

        // Reference the ListView
        val listView: ListView = view.findViewById(R.id.dietTrackerListView)

        // List of diet options
        val dietOptions = arrayOf("Breakfast", "Lunch", "Dinner")

        // Adapter to bind the diet options to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, dietOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), DietBreakfastActivity::class.java))
                1 -> startActivity(Intent(requireContext(), DietLunchActivity::class.java))
                2 -> startActivity(Intent(requireContext(), DietDinnerActivity::class.java))
            }
        }

        // Reference the Notification Bell
        val notificationBell: ImageButton = view.findViewById(R.id.notificationBell)

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            // Show dialog when bell is clicked
            showNotificationDialog()
        }

        return view
    }

    // Function to show a message dialog
    private fun showNotificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage("You have no new notifications.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
