package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

//code attribution
////Login and registration page
////Technical Skillz
////link:https://youtu.be/BLfqZlUI_MM?si=-mAh9MMLgJix1CFr
class RegistrationActivity : AppCompatActivity() {

    // Declare UI components
    private lateinit var logoImage: ImageView
    private lateinit var username: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var termsCheckbox: CheckBox
    private lateinit var registerButton: Button
    private lateinit var signinLink: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        // Initialize UI components
        initializeUI()

        // Set up click listeners for buttons and text views
        setUpEventHandlers()
    }

    /**
     * Method to initialize UI components
     */
    private fun initializeUI() {
        // Initialize UI components by their IDs
        logoImage = findViewById(R.id.logoImage)
        username = findViewById(R.id.username)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        termsCheckbox = findViewById(R.id.terms_checkbox)
        registerButton = findViewById(R.id.register_button)
        signinLink = findViewById(R.id.signin_link)
    }

    /**
     * Method to set up event handlers for button clicks
     */
    private fun setUpEventHandlers() {
        // Set click listener for Register button
        registerButton.setOnClickListener {
            // Get user input
            val usernameInput = username.text.toString().trim()
            val emailInput = email.text.toString().trim()
            val passwordInput = password.text.toString().trim()

            // Basic validation
            if (usernameInput.isEmpty() || emailInput.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!termsCheckbox.isChecked) {
                Toast.makeText(this, "Please accept the terms and conditions", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Registration logic (e.g., sending data to a server)
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()

            // Navigate to another activity (e.g., LoginActivity)
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        // Set click listener for Sign-In link
        signinLink.setOnClickListener {
            // Navigate to the login activity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

}
