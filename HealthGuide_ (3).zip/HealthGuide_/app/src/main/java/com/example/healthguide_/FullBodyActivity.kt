package com.example.healthguide_ // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class FullBodyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_body) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImageFullBody: ImageView = findViewById(R.id.imageBeginnerFullBody)
        val intermediateImageFullBody: ImageView = findViewById(R.id.imageIntermediateFullBody)
        val advancedImageFullBody: ImageView = findViewById(R.id.imageAdvancedFullBody)

        beginnerImageFullBody.setOnClickListener {
            showDetailsDialog("Beginner Full Body Details", "Bodyweight Squats (3 sets of 15)\n" +
                    "Push-ups (3 sets of 10)\n" +
                    "Plank (3 sets of 30 seconds)\n")
        }

        intermediateImageFullBody.setOnClickListener {
            showDetailsDialog("Intermediate Full Body Details", "Burpees (4 sets of 15)\n" +
                    "Deadlifts (4 sets of 10)\n" +
                    "Kettlebell Swings (4 sets of 12)\n" +
                    "Side Plank (4 sets of 30 seconds per side)\n")
        }

        advancedImageFullBody.setOnClickListener {
            showDetailsDialog("Advanced Full Body Details", "Thrusters (5 sets of 12)\n" +
                    "Clean and Press (4 sets of 10)\n" +
                    "Weighted Burpees (5 sets of 20)\n" +
                    "Plank to Push-up (4 sets of 40 seconds)\n" +
                    "Renegade Rows (4 sets of 12)")
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
