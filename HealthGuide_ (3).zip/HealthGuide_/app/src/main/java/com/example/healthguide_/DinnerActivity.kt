package com.example.healthguide_

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class DinnerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dinner) // Ensure this layout exists

        // Ensure this ID matches the one in the layout file
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Find the image buttons
        val pastaButton: ImageButton = findViewById(R.id.pasta)
        val riceButton: ImageButton = findViewById(R.id.rice)

        // Set click listener for the pasta image button
        pastaButton.setOnClickListener {
            showDetailsDialog("Pasta Dinner", "Cook spaghetti. Sauté minced beef with onions and garlic, add tomato sauce, simmer, and serve over spaghetti.\n")
        }

        // Set click listener for the rice image button
        riceButton.setOnClickListener {
            showDetailsDialog("Rice Dinner", "Grill chicken breast, cook rice, and serve with steamed veggies.\n")
        }
    }

    // Function to show a dialog with details
    private fun showDetailsDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()  // Dismiss the dialog when the user clicks "OK"
            }
            .show()
    }
}
