package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        // Reference the ListView
        val listView: ListView = view.findViewById(R.id.settingsListView)

        // List of settings options
        val settingsOptions = arrayOf("Sleeping Mode", "Customisation Options", "Privacy and Security", "Help and Support", "Rating")

        // Adapter to bind the settings options to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, settingsOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), SleepingModeActivity::class.java))
                1 -> startActivity(Intent(requireContext(), CustomisationOptionsActivity::class.java))
                2 -> startActivity(Intent(requireContext(), PrivacySecurityActivity::class.java))
                3 -> startActivity(Intent(requireContext(), HelpSupportActivity::class.java))
                4 -> startActivity(Intent(requireContext(), RatingActivity::class.java))
            }
        }

        return view
    }
}
