package com.example.healthguide_

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageButton

class HealthyFoodActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_healthy_food)

        // Ensure this ID matches the one in the layout file
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }
    }
}
