package com.example.healthguide_

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.healthguide_.R

class HomeFragment : Fragment(R.layout.fragment_home) {

}