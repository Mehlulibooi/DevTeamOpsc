package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class WorkoutSectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout_section)

        // Reference to the Back Button and ListView
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val listView: ListView = findViewById(R.id.workoutListView)

        // Set click listener for the back button to navigate to the previous screen
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // List of workout categories
        val workouts = arrayOf("Upper Body", "Cardio Vascular", "Lower Body", "Full Body")

        // Adapter to bind the workout categories to the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, workouts)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, UpperBodyActivity::class.java))
                1 -> startActivity(Intent(this, CardioVascularActivity::class.java))
                2 -> startActivity(Intent(this, LowerBodyActivity::class.java))
                3 -> startActivity(Intent(this, FullBodyActivity::class.java))
            }
        }
    }
}
