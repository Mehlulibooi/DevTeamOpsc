package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.Fragment
import com.example.healthguide_.R

class HealthGuideFragment : Fragment(R.layout.fragment_health_guide) {

    private lateinit var listView: ListView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_health_guide, container, false)

        // Reference to the ListView in the layout
        listView = view.findViewById(R.id.healthGuideListView)

        // List of sections to display
        val sections = arrayOf("Recipes Section", "Workout Section", "Food Section")

        // Adapter to bind the list of sections to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, sections)
        listView.adapter = adapter

        // Set a click listener for each item in the list
        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), RecipeSectionActivity::class.java))
                1 -> startActivity(Intent(requireContext(), WorkoutSectionActivity::class.java))
                2 -> startActivity(Intent(requireContext(), FoodSectionActivity::class.java))
            }
        }

        return view
    }
}
