package com.example.healthguide_

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageButton

class BodyBuildingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_body_building)

        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }
    }
}
