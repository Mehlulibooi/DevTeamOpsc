package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.Fragment

class DietTrackerFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_diet_tracker, container, false)

        // Reference the ListView
        val listView: ListView = view.findViewById(R.id.dietTrackerListView)

        // List of diet options
        val dietOptions = arrayOf("Breakfast", "Lunch", "Dinner")

        // Adapter to bind the diet options to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, dietOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), DietBreakfastActivity::class.java))
                1 -> startActivity(Intent(requireContext(), DietLunchActivity::class.java))
                2 -> startActivity(Intent(requireContext(), DietDinnerActivity::class.java))
            }
        }

        return view
    }
}
