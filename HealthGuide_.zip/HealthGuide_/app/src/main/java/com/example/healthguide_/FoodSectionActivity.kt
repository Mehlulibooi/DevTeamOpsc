package com.example.healthguide_

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class FoodSectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_section)

        // Reference the Back Button and ListView
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val listView: ListView = findViewById(R.id.foodListView)

        // Set click listener for the back button to navigate to the previous screen
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // List of food categories
        val foodItems = arrayOf("Healthy Food", "Power Bites", "Body Building")

        // Adapter to bind the food categories to the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, foodItems)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, HealthyFoodActivity::class.java))
                1 -> startActivity(Intent(this, PowerBitesActivity::class.java))
                2 -> startActivity(Intent(this, BodyBuildingActivity::class.java))
            }
        }
    }
}
